README

Course: cs400
Semester: Fall 2019
Project name: Social Network
Team Members:
1. Aileen Lee, Lecture 002, xteam 95
2. Connor Kubiak, Lecture 001, crkubiak@wisc.edu
3. John Butler, Lecture 002, xteam95 jmbutler5@wisc.edu
4. Chase Flackey, Lecture 001, cflackey@wisc.edu
5. Matthew Zwinger, Lecture 002, xteam 77
