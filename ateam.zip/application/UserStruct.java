package application;

public interface UserStruct {
	String getName();
}
