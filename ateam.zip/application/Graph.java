package application;

import java.util.List;
import java.util.Set;

public class Graph implements GraphADT<UserStruct> {

	public Graph() {
		//TODO this should be an undirected graph
	}

	@Override
	public void addVertex(UserStruct vertex) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addEdge(UserStruct vertex1, UserStruct vertex2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeEdge(UserStruct vertex1, UserStruct vertex2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeVertex(UserStruct vertex) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Set<UserStruct> getAllVertecies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean contains(UserStruct vertex) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<UserStruct> getAdjacentVerticesOf() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int order() {
		// TODO Auto-generated method stub
		return 0;
	}
}
